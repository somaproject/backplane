/* See
 * http://www.linuxhq.com/lnxlists/linux-gcc/lg_9902/msg00044.html
 * http://www.informatik.uni-oldenburg.de/~joey/Linux/Tips+Tricks/register-frame.html
 * http://www.rtems.com/rtems/maillistArchives/rtems-snapshots/1999/december/msg00078.html
 * http://lists.debian.org/lsb-spec/1999/lsb-spec-199903/msg00002.html
 * http://freestandards.org/pipermail/lsb-test/2002-January/000649.html
 */
__register_frame_info() {}
__deregister_frame_info() {}
