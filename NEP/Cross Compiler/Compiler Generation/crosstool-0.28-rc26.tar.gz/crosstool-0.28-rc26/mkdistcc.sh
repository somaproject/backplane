#!/bin/sh
# Compile local patched copy of distcc for use by crosstool

set -ex

abort() {
	echo $@
	exec false
}

test -z "${RESULT_TOP}"       && abort "Please set RESULT_TOP to the top of the crosstool tree"
test -z "${TARBALLS_DIR}"     && abort "Please set TARBALLS_DIR to the directory to download tarballs to."

# Most subdirectories of $RESULT_TOP are for target architectures;
# create a new one just to hold stuff targeting the build machine.
PREFIX=$RESULT_TOP/common
rm -rf $PREFIX
mkdir -p $PREFIX/bin $PREFIX/etc
chmod 755 $PREFIX $PREFIX/bin $PREFIX/etc

# Install mkdistcclinks.sh, which creates symlinks and install-distccd.sh
install mkdistcclinks.sh $PREFIX/bin

# Install config.guess, which comes in handy when trying to figure
# out what kind of machine we're running on
install config.guess $PREFIX/bin

# Install templates that will be expanded and installed by install-distccd.sh
install -m 644 crosstool-distccd-linux.sh.in $PREFIX/etc
install -m 644 crosstool-distccd-cygwin.sh.in $PREFIX/etc
install -m 644 crosstool-distccd-mac.sh.in $PREFIX/etc
install -m 644 StartupParameters.plist $PREFIX/etc

# Make a scratch directory for building
mkdir -p build
cd build

#----- Distcc -----
DISTCC=distcc-2.14
if test ! -f $TARBALLS_DIR/$DISTCC.tar.bz2; then
   wget -P $TARBALLS_DIR -c http://distcc.samba.org/ftp/distcc/$DISTCC.tar.bz2
fi
rm -rf $DISTCC
tar -xjvf $TARBALLS_DIR/$DISTCC.tar.bz2
cd $DISTCC
for a in ../../patches/$DISTCC/*.patch; do
    if test -f $a; then
	patch -g0 -p1 < $a
    fi
done
./configure --prefix=$PREFIX $EXTRA_DISTCC_CONFIG
make 
make install
cd ..

# Create a unique name for this distcc in case startup scripts want one
ln -s $PREFIX/bin/distccd $PREFIX/bin/crosstool-distccd
