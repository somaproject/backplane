#!/bin/sh
set -ex
TARBALLS_DIR=$HOME/downloads
RESULT_TOP=/opt/crosstool
export TARBALLS_DIR RESULT_TOP
GCC_LANGUAGES="c,c++"
export GCC_LANGUAGES

# Really, you should do the mkdir before running this,
# and chown /opt/crosstool to yourself so you don't need to run as root.
mkdir -p $RESULT_TOP

# Build the toolchain.  Takes a couple hours and a couple gigabytes.
#
# Can't build glibc-2.95.3 for alpha yet; it fails with
#  build/alpha-unknown-linux-gnu/gcc-2.95.3-glibc-2.2.2/gcc-2.95.3/gcc/libgcc-2.c: In function `__muldi3':
#  libgcc-2.c:298: Internal compiler error in `expand_assignment', at expr.c:3393
# Can't build glibc-2.2.5 with gcc-3.3 for alpha yet; it fails with
#  internals.h:381: error: asm-specifier for variable `__self' conflicts with asm clobber list
#  make[2]: *** [alpha-unknown-linux-gnu/gcc-3.3-glibc-2.2.5/build-glibc/linuxthreads/attr.o] Error 1
#
# Can't build glibc-2.3.2+gcc-3.3 or later with binutils-2.14.90.* for alpha; it fails with
# linuxthreads/sysdeps/unix/sysv/linux/alpha/vfork.S:63: Warning: .ent directive without matching .end
# linuxthreads/sysdeps/unix/sysv/linux/alpha/vfork.S:63: Error: can't resolve `0' {.text section} - `L0
# make[2]: *** [/home/dank/crosstool-0.27/build/alpha-unknown-linux-gnu/gcc-3.3-glibc-2.3.2/build-glibc/posix/vfork.o] Error 1
# http://sources.redhat.com/ml/libc-alpha/2004-01/msg00255.html
#
#eval `cat alpha.dat gcc-3.3-glibc-2.3.2.dat`      sh all.sh --notest
#eval `cat alpha.dat gcc-3.3.1-glibc-2.3.2.dat`    sh all.sh --notest
#eval `cat alpha.dat gcc-3.3.2-glibc-2.3.2.dat`    sh all.sh --notest
#eval `cat alpha.dat gcc-3.3.3-glibc-2.3.2.dat`    sh all.sh --notest
 eval `cat alpha.dat gcc-3.4.0-glibc-2.3.2.dat`    sh all.sh --notest

# Following combination seems to build, though:
#eval `cat alpha.dat gcc-3.2.3-glibc-2.2.5.dat`    sh all.sh --notest

echo Done.
