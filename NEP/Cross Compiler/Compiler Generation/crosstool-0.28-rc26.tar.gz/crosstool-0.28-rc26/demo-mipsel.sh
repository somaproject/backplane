#!/bin/sh
set -ex
# Create a toolchain for the Linksys wrt54g
# See http://seattlewireless.net/index.cgi/LinksysWrt54g
#     http://www.batbox.org/wrt54g-linux.html
# Note: recent wrt54g firmware uses uclibc, which behaves like a subsetted glibc.
# There are patches to build uclibc toolchains in the contrib directory,
# but they're not integrated yet.  However, you can still use a glibc
# toolchain; you'll either have to 
#  a) not call the missing functions,
#  b) use a stub library like http://www.xse.com/leres/tivo/downloads/libtivohack/
# or c) link your programs statically if you want them to run on
# the wrt54g.

TARBALLS_DIR=$HOME/downloads
RESULT_TOP=/opt/crosstool
export TARBALLS_DIR RESULT_TOP
GCC_LANGUAGES="c,c++"
export GCC_LANGUAGES

# Really, you should do the mkdir before running this,
# and chown /opt/crosstool to yourself so you don't need to run as root.
mkdir -p $RESULT_TOP

# Build the toolchain.  Takes a couple hours and a couple gigabytes.
#eval `cat mipsel.dat gcc-3.2.3-glibc-2.2.3.dat`        sh all.sh --notest
#eval `cat mipsel.dat gcc-3.2.3-glibc-2.2.5.dat`        sh all.sh --notest
#eval `cat mipsel.dat gcc-3.3-glibc-2.3.2.dat`          sh all.sh --notest
#eval `cat mipsel.dat gcc-3.3.2-glibc-2.3.2.dat`        sh all.sh --notest
#eval `cat mipsel.dat gcc-3.3.3-glibc-2.3.2.dat`        sh all.sh --notest

 eval `cat mipsel.dat gcc-3.4.0-glibc-2.3.2.dat`        sh all.sh --notest
# gcc-3.4.0 currently fails with
# mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crtn.o(.text+0x0):/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crtn.S:20: multiple definition of `dummy'
# mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crti.o(.text+0x0):/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crti.S:42: first defined here
# mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crtn.o(.text+0x18):/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crtn.S:37: multiple definition of `_init'
# mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crti.o(.text+0x30):/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crti.S:76: first defined here
# mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crtn.o(.init+0x1c):/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crtn.S:88: multiple definition of `_fini'
# mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crti.o(.init+0x10):/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crti.S:48: first defined here
# mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crti.o(.init+0x28):/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crti.S:58: undefined reference to `i_am_not_a_leaf'
# mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crtn.o(.init+0x4c):/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crtn.S:110: undefined reference to `i_am_not_a_leaf'
# mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crtn.o(.init+0x50):/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/csu/crtn.S:111: undefined reference to `i_am_not_a_leaf'
# collect2: ld returned 1 exit status
# make[2]: *** [/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/build-glibc/iconv/iconvconfig] Error 1
# make[2]: Leaving directory `/home/dank/wk/crosstool-0.28-rc6/build/mipsel-unknown-linux-gnu/gcc-3.4.0-glibc-2.3.2/glibc-2.3.2/iconv'
# See
# http://sources.redhat.com/ml/libc-alpha/2003-07/msg00117.html
# for a possible fix.

echo Done.
